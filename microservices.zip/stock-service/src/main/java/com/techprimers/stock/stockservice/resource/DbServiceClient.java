package com.techprimers.stock.stockservice.resource;

public interface DbServiceClient {

}
